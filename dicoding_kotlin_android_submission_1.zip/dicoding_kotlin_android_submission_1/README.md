# Football Club
Ini adalah Submission 1: Aplikasi Football Club dari kursus online dicoding.com. Menerapkan Kotlin Android Extensions, Anko Layout, dan Anko Commons.

## Preview
<img src="https://github.com/omrobbie/kotlin-football-club/blob/master/screenshot/preview1.png" width=256/>&nbsp;
<img src="https://github.com/omrobbie/kotlin-football-club/blob/master/screenshot/preview2.png" width=256/>&nbsp;

## Submission 1
Anda sudah melewati beberapa modul pada akademi ini. Beberapa yang sudah Anda pelajari adalah pengenalan dan dasar-dasar Kotlin; membuat aplikasi Android dengan Kotlin; Kotlin Android Extensions; dan Anko. Untuk bisa lanjut ke modul berikutnya, Anda harus mengirimkan proyek dengan beberapa kriteria yang sudah ditentukan.

### Fitur yang harus ada pada aplikasi Anda adalah :
1. Menampilkan list data ke dalam RecyclerView.
2. Menampilkan halaman detail ketika item dipilih.
3. Menerapkan Kotlin Android Extensions.
4. Menerapkan Anko Layout 
5. Menerapkan Anko Commons.

# Update
Bagi teman-teman yang masih mengikuti kelas dari dicoding, [Kelas Kotlin Android Developer Expert](https://www.dicoding.com/academies/55 "klik untuk melihat kelas"). Silahkan gunakan source ini sebagai bahan referensi, tapi **TIDAK** untuk disalin secara utuh tanpa tau cara implementasinya.

Ayolah kawan.. Kalian sudah bayar mahal untuk ikut kelas ini, kalian harus dapat ilmunya. Percuma kalian dapat sertifikat dari dicoding kalau di kemudian hari kalian tidak mendapatkan ilmunya dari sini.

Semangat kawan.. Perjalanan masih panjang. Lakukan yang terbaik yang kalian bisa. Silahkan tanya saya jika ada yang kurang dimengerti. Kalau saya bisa bantu, pasti saya dampingi.

Mari kita maju bersama-sama..
