package com.surya.footballclub.util

class Constants {
    companion object{
        const val DATA_ITEM = "DataItem"
        val league_logo = 1
        val league_name = 2
    }
}