package com.surya.footballclub.ui.home

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.surya.footballclub.data.model.DataItem
import com.surya.footballclub.R
import org.jetbrains.anko.*

class MainActivity : AppCompatActivity() {

    var itemList: MutableList<DataItem> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        loadDataFromResource()
        MainActivityUI(itemList).setContentView(this)
    }

    fun loadDataFromResource() {
        val nameList = resources.getStringArray(R.array.league_name)
        val imageList = resources.obtainTypedArray(R.array.league_logo)
        val descriptionList = resources.getStringArray(R.array.league_description)

        itemList.clear()
        for (i in nameList.indices)itemList.add(DataItem(imageList.getResourceId(i, 0), nameList[i], descriptionList[i]))
        imageList.recycle()
    }
}
